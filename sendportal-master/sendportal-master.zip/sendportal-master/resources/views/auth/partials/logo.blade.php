<div class="logo text-center">
    <img src="{{ asset('/vendor/sendportal/img/logo-gray.png') }}" alt="SendPortal" width="225px" class="my-5">
</div>
