<p>{{__('Hi!')}}</p>

<p>{{__(':userName has added you to their workspace on SendPortal!', ['userName' => $invitation->workspace->owner->name])}}</p>

<p>{{__('Since you already have an account, you have automatically been added to the workspace.')}}</p>

<p>{{__('See you soon!')}}</p>
